package com.sergii.prykhodko.aggregator.web.model;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

import static com.sergii.prykhodko.aggregator.web.model.SourceType.PRICING;
import static com.sergii.prykhodko.aggregator.web.model.SourceType.SHIPMENTS;
import static com.sergii.prykhodko.aggregator.web.model.SourceType.TRACK;

@Data
@Builder(access = AccessLevel.PRIVATE)
public class OutboundData<T> {

  private final SourceType source;
  private final Map<String, T> responseData;

  public static OutboundData<List<String>> shipmentsData(Map<String, List<String>> responseData) {
    return OutboundData.<List<String>>builder()
        .source(SHIPMENTS)
        .responseData(responseData)
        .build();
  }

  public static OutboundData<String> trackData(Map<String, String> responseData) {
    return OutboundData.<String>builder()
        .source(TRACK)
        .responseData(responseData)
        .build();
  }

  public static OutboundData<Double> pricingData(Map<String, Double> responseData) {
    return OutboundData.<Double>builder()
        .source(PRICING)
        .responseData(responseData)
        .build();
  }
}
