package com.sergii.prykhodko.aggregator.web.outbound.client;

import com.sergii.prykhodko.aggregator.configuration.ExternalWebclientProperties;
import com.sergii.prykhodko.aggregator.web.groupProxy.DataClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.Collections.*;

public class TrackWebClient implements DataClient<String> {

  private final WebClient webclient;

  private static final ParameterizedTypeReference<Map<String, String>> TYPE_REF = new ParameterizedTypeReference<>() {};


  public TrackWebClient(ExternalWebclientProperties externalWebclientProperties) {
    this.webclient = WebClient.builder()
        .baseUrl(externalWebclientProperties.getBaseUri())
        .build();
  }

  public Mono<Map<String, String>> getForData(Set<String> trackIds) {
    String trackQueryParams = String.join(",", trackIds);

    return webclient.get()
        .uri(uriBuilder -> uriBuilder
            .path("/track")
            .queryParam("q", trackQueryParams)
            .build()
        )
        .retrieve()
        .bodyToMono(TYPE_REF)
        .onErrorReturn(emptyMap());
  }
}
