package com.sergii.prykhodko.aggregator.web.service.retriver;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import reactor.core.publisher.Mono;

public interface OutboundDataRetriever<T> {

  Mono<OutboundData<T>> retrieveData(AggregationDto aggregationDto);
}
