package com.sergii.prykhodko.aggregator.web.groupProxy;

import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;

public interface DataClient<T> {
  Mono<Map<String, T>> getForData(Set<String> keys);
}
