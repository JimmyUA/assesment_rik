package com.sergii.prykhodko.aggregator.web.service;

import com.sergii.prykhodko.aggregator.web.converter.OutboundDataConverter;
import com.sergii.prykhodko.aggregator.web.model.AggregatedData;
import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.service.retriver.PricingDataRetriever;
import com.sergii.prykhodko.aggregator.web.service.retriver.ShipmentsDataRetriever;
import com.sergii.prykhodko.aggregator.web.service.retriver.TrackDataRetriever;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service
@RequiredArgsConstructor
public class AggregationService {

  private final OutboundDataConverter outboundDataConverter;
  private final ShipmentsDataRetriever shipmentsDataRetriever;
  private final TrackDataRetriever trackDataRetriever;
  private final PricingDataRetriever pricingDataRetriever;


  public Mono<AggregatedData> aggregateResponse(AggregationDto aggregationDto) {
    return Mono.zip(
            pricingDataRetriever.retrieveData(aggregationDto),
            shipmentsDataRetriever.retrieveData(aggregationDto),
            trackDataRetriever.retrieveData(aggregationDto)
        )
        .map(outboundData -> outboundDataConverter.convert(aggregationDto, outboundData));
  }
}
