package com.sergii.prykhodko.aggregator.configuration;

import com.sergii.prykhodko.aggregator.web.groupProxy.DataClient;
import com.sergii.prykhodko.aggregator.web.groupProxy.BatchClientProxy;
import com.sergii.prykhodko.aggregator.web.outbound.client.PricingWebClient;
import com.sergii.prykhodko.aggregator.web.outbound.client.ShipmentsWebClient;
import com.sergii.prykhodko.aggregator.web.outbound.client.TrackWebClient;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
@EnableConfigurationProperties({ExternalWebclientProperties.class, BatchClientProperties.class})
public class WebClientConfiguration {

  @Bean
  public DataClient<List<String>> shipmentsWebClient(ExternalWebclientProperties externalWebclientProperties, BatchClientProperties batchClientProperties){
    final ShipmentsWebClient shipmentsWebClient = new ShipmentsWebClient(externalWebclientProperties);

    return new BatchClientProxy<>(shipmentsWebClient, batchClientProperties);
  }

  @Bean
  public DataClient<String> trackWebClient(ExternalWebclientProperties externalWebclientProperties, BatchClientProperties batchClientProperties){
    final TrackWebClient trackWebClient = new TrackWebClient(externalWebclientProperties);

    return new BatchClientProxy<>(trackWebClient, batchClientProperties);
  }

  @Bean
  public DataClient<Double> pricingWebClient(ExternalWebclientProperties externalWebclientProperties,BatchClientProperties batchClientProperties){
    final PricingWebClient pricingWebClient = new PricingWebClient(externalWebclientProperties);

    return new BatchClientProxy<>(pricingWebClient, batchClientProperties);
  }
}
