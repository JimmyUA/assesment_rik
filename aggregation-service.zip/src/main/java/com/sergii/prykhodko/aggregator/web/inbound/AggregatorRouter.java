package com.sergii.prykhodko.aggregator.web.inbound;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;

@Configuration
public class AggregatorRouter {

  @Bean
  public RouterFunction<ServerResponse> route(AggregatorRequestHandler aggregatorRequestHandler) {
    return RouterFunctions.route(GET("/aggregation")
                                     .and(accept(APPLICATION_JSON)), aggregatorRequestHandler::processRequest);
  }
}
