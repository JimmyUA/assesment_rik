package com.sergii.prykhodko.aggregator.web.service.retriver;

import com.sergii.prykhodko.aggregator.web.groupProxy.DataClient;
import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.outbound.client.TrackWebClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class TrackDataRetriever implements OutboundDataRetriever<String> {

  private final DataClient<String> trackWebClient;

  @Override
  public Mono<OutboundData<String>> retrieveData(AggregationDto aggregationDto) {
    return trackWebClient.getForData(aggregationDto.getTrack())
        .map(OutboundData::trackData);
  }
}