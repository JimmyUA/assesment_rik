package com.sergii.prykhodko.aggregator.web.service.extractor;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.model.SourceType;

import java.util.Map;

public interface SourceAwareDataExtractor<T> {

  SourceType managedSourceType();

 Map<String, T> extract(AggregationDto aggregationDto, OutboundData<T> outboundData);
}
