package com.sergii.prykhodko.aggregator.web.service.extractor;


import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public abstract class AbstractDataExtractor<T> implements SourceAwareDataExtractor<T> {


  abstract Set<String> extractKeys(AggregationDto aggregationDto);

  @Override
  public Map<String, T> extract(AggregationDto aggregationDto, OutboundData<T> outboundData) {

    return extractKeys(aggregationDto).stream()
        .collect(toMap(
            shipmentKey -> shipmentKey,
            shipmentKey -> extractValueOrNull(outboundData, shipmentKey)
        ));
  }

  private T extractValueOrNull(OutboundData<T> outboundData, String dataKey) {
    final Map<String, T> responseData = outboundData.getResponseData();
    return responseData == null ? null : responseData.get(dataKey);
  }

  public static <V, K, U>
  Collector<V, ?, Map<K, U>> toMap(Function<? super V, ? extends K> keyMapper,
                                   Function<? super V, ? extends U> valueMapper) {
    return Collectors.collectingAndThen(
        Collectors.toList(),
        list -> {
          Map<K, U> result = new HashMap<>();
          for (V item : list) {
            K key = keyMapper.apply(item);
            if (result.putIfAbsent(key, valueMapper.apply(item)) != null) {
              throw new IllegalStateException(String.format("Duplicate key %s", key));
            }
          }
          return result;
        });
  }

}
