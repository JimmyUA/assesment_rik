package com.sergii.prykhodko.aggregator.web.model;

import lombok.Builder;
import lombok.Data;

import java.util.Set;

@Data
@Builder
public final class AggregationDto {
  private final Set<String> pricing;
  private final Set<String> track;
  private final Set<String> shipments;

}
