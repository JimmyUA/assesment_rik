package com.sergii.prykhodko.aggregator.web.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@Builder
public final class AggregatedResponse {
  private final Map<String, Double> pricing;
  private final Map<String, String> track;
  private final Map<String, List<String>> shipments;

}