package com.sergii.prykhodko.aggregator.web.service.extractor;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.SourceType;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

import static com.sergii.prykhodko.aggregator.web.model.SourceType.SHIPMENTS;

@Component
public class ShipmentsDataExtractor extends AbstractDataExtractor<List<String>> {


  @Override
  public SourceType managedSourceType() {
    return SHIPMENTS;
  }


  @Override
  Set<String> extractKeys(AggregationDto aggregationDto) {
    return aggregationDto.getShipments();
  }
}
