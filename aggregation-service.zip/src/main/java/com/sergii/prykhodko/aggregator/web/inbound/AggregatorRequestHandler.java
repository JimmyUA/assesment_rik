package com.sergii.prykhodko.aggregator.web.inbound;

import com.sergii.prykhodko.aggregator.web.converter.AggregationRequestConverter;
import com.sergii.prykhodko.aggregator.web.model.AggregatedData;
import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.service.AggregationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@Component
@RequiredArgsConstructor
public class AggregatorRequestHandler {

  private final AggregationService aggregationService;
  private final AggregationRequestConverter aggregationRequestConverter;


  public Mono<ServerResponse> processRequest(ServerRequest serverRequest) {

    final AggregationDto aggregationDto = aggregationRequestConverter.convert(serverRequest);

    final Mono<AggregatedData> aggregatedDataMono = aggregationService.aggregateResponse(aggregationDto);

    return ServerResponse.ok().contentType(APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(aggregatedDataMono, AggregatedData.class));
  }
}
