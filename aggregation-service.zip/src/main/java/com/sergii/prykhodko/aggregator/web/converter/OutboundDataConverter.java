package com.sergii.prykhodko.aggregator.web.converter;

import com.sergii.prykhodko.aggregator.web.model.AggregatedData;
import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.service.extractor.PricingDataExtractor;
import com.sergii.prykhodko.aggregator.web.service.extractor.ShipmentsDataExtractor;
import com.sergii.prykhodko.aggregator.web.service.extractor.TrackDataExtractor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.util.function.Tuple3;

import java.util.List;

@Component
@RequiredArgsConstructor
public class OutboundDataConverter {

  private final PricingDataExtractor pricingDataExtractor;
  private final ShipmentsDataExtractor shipmentsDataExtractor;
  private final TrackDataExtractor trackDataExtractor;

  public AggregatedData convert(AggregationDto aggregationDto,
                                Tuple3<OutboundData<Double>, OutboundData<List<String>>, OutboundData<String>> outboundData) {
    OutboundData<Double> pricingData = outboundData.getT1();
    OutboundData<List<String>> shipmentData = outboundData.getT2();
    OutboundData<String> trackData = outboundData.getT3();

    return AggregatedData.builder()
        .pricing(pricingDataExtractor.extract(aggregationDto, pricingData))
        .shipments(shipmentsDataExtractor.extract(aggregationDto, shipmentData))
        .track(trackDataExtractor.extract(aggregationDto, trackData))
        .build();
  }
}