package com.sergii.prykhodko.aggregator.web.groupProxy;

import com.sergii.prykhodko.aggregator.configuration.BatchClientProperties;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static java.util.stream.Collectors.toUnmodifiableSet;

public class BatchClientProxy<T> implements DataClient<T> {

  private final DataClient<T> webClient;
  private final Set<String> keysStore;
  private final Integer batchKeysTimeoutSeconds;
  private final Integer keysThreshold;
  private CountDownLatch collectParametersSyncronizer;
  private Mono<Map<String, T>> responseMono;

  public BatchClientProxy(DataClient<T> webClient, BatchClientProperties batchClientProperties) {
    this.keysStore = new ConcurrentHashMap<String, String>().newKeySet();
    this.webClient = webClient;
    this.batchKeysTimeoutSeconds = batchClientProperties.getBatchKeysTimeoutSeconds();
    this.keysThreshold = batchClientProperties.getKeysThreshold();
    this.collectParametersSyncronizer = new CountDownLatch(5);
  }


  @Override
  public Mono<Map<String, T>> getForData(Set<String> keys) {
    fillInKeysContainer(keys);
    waitForCondition();
    initRequestMonoIfAbsent();

    return responseMono;
  }

  private synchronized void fillInKeysContainer(Set<String> keys) {
    if (keysStore.isEmpty()) {
      this.responseMono = null;
    }

    final Set<String> uniqueKeys = keys.stream()
        .filter(key -> !keysStore.contains(key))
        .collect(toUnmodifiableSet());

    keysStore.addAll(keys);

    uniqueKeys.forEach(key -> collectParametersSyncronizer.countDown());
  }

  private void waitForCondition() {
    try {
      collectParametersSyncronizer.await(batchKeysTimeoutSeconds, TimeUnit.SECONDS);
    }
    catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  private synchronized void initRequestMonoIfAbsent() {
    if (this.responseMono == null) {
      this.responseMono = this.webClient.getForData(keysStore)
          .doOnNext(t -> {
            keysStore.clear();
            this.collectParametersSyncronizer = new CountDownLatch(keysThreshold);
          });
    }
  }
}
