package com.sergii.prykhodko.aggregator.web.model;

public enum SourceType {
  TRACK, PRICING, SHIPMENTS
}
