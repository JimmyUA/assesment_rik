package com.sergii.prykhodko.aggregator.web.converter;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;

import java.util.Arrays;
import java.util.Set;

import static java.util.stream.Collectors.toUnmodifiableSet;

@Component
public class AggregationRequestConverter implements Converter<ServerRequest, AggregationDto> {


  @Override
  public AggregationDto convert(ServerRequest serverRequest) {
    return AggregationDto.builder()
        .pricing(extractPricing(serverRequest))
        .track(extractTrack(serverRequest))
        .shipments(extractShipments(serverRequest))
        .build();
  }

  private Set<String> extractPricing(ServerRequest serverRequest) {
    return extractByQueryParam(serverRequest, "pricing");
  }

  private Set<String> extractShipments(ServerRequest serverRequest) {
    return extractByQueryParam(serverRequest, "shipments");
  }

  private Set<String> extractTrack(ServerRequest serverRequest) {
    return extractByQueryParam(serverRequest, "track");
  }

  private Set<String> extractByQueryParam(ServerRequest serverRequest, String track) {
    return serverRequest.queryParam(track)
        .map(this::splitToSet)
        .orElse(Set.of());
  }

  private Set<String> splitToSet(String queryParameter) {
    return Arrays.stream(queryParameter.split(","))
        .collect(toUnmodifiableSet());
  }
}
