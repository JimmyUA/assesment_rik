package com.sergii.prykhodko.aggregator.web.service.retriver;

import com.sergii.prykhodko.aggregator.web.groupProxy.DataClient;
import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.outbound.client.PricingWebClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class PricingDataRetriever implements OutboundDataRetriever<Double> {

  private final DataClient<Double> pricingWebClient;


  @Override
  public Mono<OutboundData<Double>> retrieveData(AggregationDto aggregationDto) {
    return pricingWebClient.getForData(aggregationDto.getPricing())
        .map(OutboundData::pricingData);
  }
}