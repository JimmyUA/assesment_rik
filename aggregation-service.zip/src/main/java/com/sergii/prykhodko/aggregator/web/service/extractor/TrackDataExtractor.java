package com.sergii.prykhodko.aggregator.web.service.extractor;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.model.SourceType;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import static com.sergii.prykhodko.aggregator.web.model.SourceType.TRACK;
import static java.util.stream.Collectors.toMap;

@Component
public class TrackDataExtractor extends AbstractDataExtractor<String> {


  @Override
  public SourceType managedSourceType() {
    return TRACK;
  }


  @Override
  Set<String> extractKeys(AggregationDto aggregationDto) {
    return aggregationDto.getTrack();
  }
}
