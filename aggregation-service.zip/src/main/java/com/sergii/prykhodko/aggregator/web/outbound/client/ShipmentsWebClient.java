package com.sergii.prykhodko.aggregator.web.outbound.client;

import com.sergii.prykhodko.aggregator.configuration.ExternalWebclientProperties;
import com.sergii.prykhodko.aggregator.web.groupProxy.DataClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.Collections.emptyMap;

@Slf4j
public class ShipmentsWebClient implements DataClient<List<String>> {

  private final WebClient webclient;

  private static final ParameterizedTypeReference<Map<String, List<String>>> TYPE_REF = new ParameterizedTypeReference<>() {};


  public ShipmentsWebClient(ExternalWebclientProperties externalWebclientProperties) {
    this.webclient = WebClient.builder()
        .baseUrl(externalWebclientProperties.getBaseUri())
        .build();
  }

  public Mono<Map<String, List<String>>> getForData(Set<String> shipmentIds) {
    String shipmentQueryParams = String.join(",", shipmentIds);

    return webclient.get()
        .uri(uriBuilder -> uriBuilder
            .path("/shipments")
            .queryParam("q", shipmentQueryParams)
            .build()
        )
        .retrieve()
        .bodyToMono(TYPE_REF)
        .onErrorReturn(emptyMap());
  }
}
