package com.sergii.prykhodko.aggregator.web.service.retriver;

import com.sergii.prykhodko.aggregator.web.groupProxy.DataClient;
import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.outbound.client.ShipmentsWebClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class ShipmentsDataRetriever implements OutboundDataRetriever<List<String>> {

  private final DataClient<List<String>> shipmentsWebClient;

  @Override
  public Mono<OutboundData<List<String>>> retrieveData(AggregationDto aggregationDto) {
    return shipmentsWebClient.getForData(aggregationDto.getShipments())
        .map(OutboundData::shipmentsData);

  }

}
