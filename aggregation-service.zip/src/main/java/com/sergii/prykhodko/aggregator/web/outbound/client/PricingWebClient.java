package com.sergii.prykhodko.aggregator.web.outbound.client;

import com.sergii.prykhodko.aggregator.configuration.ExternalWebclientProperties;
import com.sergii.prykhodko.aggregator.web.groupProxy.DataClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;

import static java.util.Collections.emptyMap;

public class PricingWebClient implements DataClient<Double> {

  private final WebClient webclient;

  private static final ParameterizedTypeReference<Map<String, Double>> TYPE_REF = new ParameterizedTypeReference<>() {};


  public PricingWebClient(ExternalWebclientProperties externalWebclientProperties) {
    this.webclient = WebClient.builder()
        .baseUrl(externalWebclientProperties.getBaseUri())
        .build();
  }

  public Mono<Map<String, Double>> getForData(Set<String> countryCodes) {
    String pricingQueryParams = String.join(",", countryCodes);

    return webclient.get()
        .uri(uriBuilder -> uriBuilder
            .path("/pricing")
            .queryParam("q", pricingQueryParams)
            .build()
        )
        .retrieve()
        .bodyToMono(TYPE_REF)
        .onErrorReturn(emptyMap());
  }
}
