package com.sergii.prykhodko.aggregator.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

import java.time.Duration;

@Data
@ConstructorBinding
@ConfigurationProperties(prefix = "aggregator.client.batch")
public class BatchClientProperties {
  private final Integer batchKeysTimeoutSeconds;
  private final Integer keysThreshold;
}
