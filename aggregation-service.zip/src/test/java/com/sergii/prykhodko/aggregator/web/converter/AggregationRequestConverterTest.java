package com.sergii.prykhodko.aggregator.web.converter;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.web.reactive.function.server.ServerRequest;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Stream;

import static com.sergii.prykhodko.aggregator.testData.MockRequestUtils.buildAllParametersEmptyRequest;
import static com.sergii.prykhodko.aggregator.testData.MockRequestUtils.buildAllParametersRequest;
import static com.sergii.prykhodko.aggregator.testData.MockRequestUtils.buildEmptyPricingRequest;
import static com.sergii.prykhodko.aggregator.testData.MockRequestUtils.buildEmptyShipmentsRequest;
import static com.sergii.prykhodko.aggregator.testData.MockRequestUtils.buildEmptyTrackingRequest;
import static java.util.stream.Collectors.toUnmodifiableSet;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AggregationRequestConverterTest {


  @ParameterizedTest
  @MethodSource("requests")
  void convertsCorrect(ServerRequest serverRequest) {
    AggregationDto aggregationDto = new AggregationRequestConverter().convert(serverRequest);

    Set<String> extractedTrack = extractParametersBySource(serverRequest, "track");
    Set<String> extractedShipments = extractParametersBySource(serverRequest, "shipments");
    Set<String> extractedPricing = extractParametersBySource(serverRequest, "pricing");

    assertNotNull(aggregationDto);
    assertTrue(extractedTrack.containsAll(aggregationDto.getTrack()));
    assertTrue(extractedShipments.containsAll(aggregationDto.getShipments()));
    assertTrue(extractedPricing.containsAll(aggregationDto.getPricing()));
  }

  private Set<String> extractParametersBySource(ServerRequest serverRequest, String source) {
    return serverRequest.queryParam(source)
        .map(this::toStringsList)
        .orElse(Set.of());
  }
  private Set<String> toStringsList(String queryParameter) {
    return Arrays.stream(queryParameter.split(",")).collect(toUnmodifiableSet());
  }

  private static Stream<Arguments> requests() {
    return Stream.of(
        Arguments.of(buildAllParametersRequest()),
        Arguments.of(buildEmptyPricingRequest()),
        Arguments.of(buildEmptyTrackingRequest()),
        Arguments.of(buildEmptyShipmentsRequest()),
        Arguments.of(buildAllParametersEmptyRequest())
    );
  }

}