package com.sergii.prykhodko.aggregator.web.outbound.clinet;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.sergii.prykhodko.aggregator.configuration.ExternalWebclientProperties;
import com.sergii.prykhodko.aggregator.configuration.WireMockTest;
import com.sergii.prykhodko.aggregator.web.outbound.client.ShipmentsWebClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;

import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertTrue;


@WireMockTest
public class ShipmentWebClientTest {

  @Value("${wiremock.server.port}")
  private String port;

  private ShipmentsWebClient shipmentsWebClient;

  @BeforeEach
  void setUp() {
    shipmentsWebClient = new ShipmentsWebClient(new ExternalWebclientProperties("http://localhost:" + port));
  }

  @Test
  void hasAllKeysWhenResponseOk() {
    final Set<String> shipmentIds = Set.of("1", "2");

    final String testUrl = "/shipments?q=" + String.join(",", shipmentIds);

    WireMock.stubFor(WireMock.get(
        WireMock.urlEqualTo(testUrl)
    ).willReturn(
        WireMock.aResponse()
            .withHeader("Content-Type", "application/json;charset=UTF-8")
            .withBody("{\"1\": [\"box\", \"box\", \"pallet\"], \"2\": [\"envelope\"]}")
            .withStatus(200)
    ));

    final Map responseData = shipmentsWebClient.getForData(shipmentIds).block();

    assertTrue(responseData.keySet().containsAll(shipmentIds));
  }

  @Test
  void emptyMapForErrorResponse() {
    final Set<String> shipmentIds = Set.of("1", "2");

    final String testUrl = "/shipments?q=" + String.join(",", shipmentIds);

    WireMock.stubFor(WireMock.get(
        WireMock.urlEqualTo(testUrl)
    ).willReturn(
        WireMock.aResponse()
            .withHeader("Content-Type", "application/json;charset=UTF-8")
            .withStatus(503)
    ));

    final Map responseData = shipmentsWebClient.getForData(shipmentIds).block();

    assertTrue(responseData.isEmpty());
  }
}
