package com.sergii.prykhodko.aggregator.web.service.extractor;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.model.SourceType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.sergii.prykhodko.aggregator.web.model.SourceType.PRICING;
import static com.sergii.prykhodko.aggregator.web.model.SourceType.SHIPMENTS;
import static com.sergii.prykhodko.aggregator.web.model.SourceType.TRACK;
import static java.util.Collections.emptyMap;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class PricingDataExtractorTest {

  @Spy
  private PricingDataExtractor pricingDataExtractor;

  @Test
  void correctManagementSourceType() {
    SourceType managedSourceType = pricingDataExtractor.managedSourceType();

    assertEquals(managedSourceType, PRICING);
    assertNotEquals(managedSourceType, SHIPMENTS);
    assertNotEquals(managedSourceType, TRACK);
  }

  @Test
  void extractsPricingDataCorrect() {
    String countryCode = "NL";
    AggregationDto aggregationDto = buildAggregationDto(countryCode);
    OutboundData outboundPricingData = OutboundData.pricingData(Map.of(countryCode, 23.23));

    Map<String, ?> pricingData = pricingDataExtractor.extract(aggregationDto, outboundPricingData);

    assertEquals(pricingData.get(countryCode), outboundPricingData.getResponseData().get(countryCode));
  }


  @Test
  void nullValuesIfEmptyOutboundData() {
    String countryCode = "NL";
    AggregationDto aggregationDto = buildAggregationDto(countryCode);
    OutboundData outboundPricingData = OutboundData.pricingData(emptyMap());

    Map<String, ?> pricingData = pricingDataExtractor.extract(aggregationDto, outboundPricingData);

    assertFalse(pricingData.isEmpty());
    assertNull(pricingData.get(countryCode));
  }

  private AggregationDto buildAggregationDto(String countryCode) {
    return AggregationDto.builder()
        .pricing(Set.of(countryCode))
        .build();
  }
}