package com.sergii.prykhodko.aggregator.web.outbound.clinet;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.sergii.prykhodko.aggregator.configuration.ExternalWebclientProperties;
import com.sergii.prykhodko.aggregator.configuration.WireMockTest;
import com.sergii.prykhodko.aggregator.web.outbound.client.PricingWebClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;

import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertTrue;


@WireMockTest
public class PricingWebClientTest {

  @Value("${wiremock.server.port}")
  private String port;

  private PricingWebClient pricingWebClient;

  @BeforeEach
  void setUp() {
    pricingWebClient = new PricingWebClient(new ExternalWebclientProperties("http://localhost:" + port));
  }

  @Test
  void hasAllKeysWhenResponseOk() {
    final Set<String> countryCodes = Set.of("NL", "BE");

    final String testUrl = "/pricing?q=" + String.join(",", countryCodes);

    WireMock.stubFor(WireMock.get(
        WireMock.urlEqualTo(testUrl)
    ).willReturn(
        WireMock.aResponse()
            .withHeader("Content-Type", "application/json;charset=UTF-8")
            .withBody("{\"NL\": 12.12, \"BE\": 13.13}")
            .withStatus(200)
    ));

    final Map responseData = pricingWebClient.getForData(countryCodes).block();

    assertTrue(responseData.keySet().containsAll(countryCodes));
  }

  @Test
  void emptyMapForErrorResponse() {
    final Set<String> countryCodes = Set.of("NL", "BE");

    final String testUrl = "/pricing?q=" + String.join(",", countryCodes);

    WireMock.stubFor(WireMock.get(
        WireMock.urlEqualTo(testUrl)
    ).willReturn(
        WireMock.aResponse()
            .withHeader("Content-Type", "application/json;charset=UTF-8")
            .withStatus(503)
    ));

    final Map responseData = pricingWebClient.getForData(countryCodes).block();

    assertTrue(responseData.isEmpty());
  }
}
