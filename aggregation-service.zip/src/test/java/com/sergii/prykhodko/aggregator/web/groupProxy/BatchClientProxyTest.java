package com.sergii.prykhodko.aggregator.web.groupProxy;

import com.sergii.prykhodko.aggregator.configuration.BatchClientProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toUnmodifiableSet;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class BatchClientProxyTest {

  @Mock
  private DataClient<Double> dataClient;

  @Captor
  private ArgumentCaptor<Set<String>> keysCaptor;

  private BatchClientProxy<Double> batchClientProxy;

  @BeforeEach
  void setUp() {
    batchClientProxy = new BatchClientProxy<>(dataClient, new BatchClientProperties(5, 5));
    doReturn(Mono.just(Map.of()))
        .when(dataClient)
        .getForData(anySet());
  }

  @Test
  void eachThreadRetrievesSameMono() {
    final Set<CompletableFuture<Mono<Map<String, Double>>>> retrievedMonos = Stream.of(1, 2, 3)
        .map(requestNumber -> CompletableFuture.supplyAsync(dataClinetRequestSupplier()))
        .collect(toUnmodifiableSet());

    final Set<Mono<Map<String, Double>>> monos = retrievedMonos.stream()
        .map(CompletableFuture::join)
        .collect(Collectors.toSet());

    assertEquals(1, monos.size());
  }

  @Test
  void dataClientIsCalledThisAllKeysFromEachThread() {
    final Set<CompletableFuture<Mono<Map<String, Double>>>> retrievedMonos = Stream.of(1, 2, 3)
        .map(requestNumber -> CompletableFuture.supplyAsync(dataClinetRequestSupplier()))
        .collect(toUnmodifiableSet());

    final Set<Mono<Map<String, Double>>> monos = retrievedMonos.stream()
        .map(CompletableFuture::join)
        .collect(Collectors.toSet());

    verify(dataClient).getForData(keysCaptor.capture());
    assertEquals(6, keysCaptor.getValue().size());
  }

  @Test
  void executeRequestBeforeReachingThresholdAfterTimeout() {
    final Set<CompletableFuture<Mono<Map<String, Double>>>> retrievedMonos = Stream.of(1, 2)
        .map(requestNumber -> CompletableFuture.supplyAsync(dataClinetRequestSupplier()))
        .collect(toUnmodifiableSet());

    final Set<Mono<Map<String, Double>>> monos = retrievedMonos.stream()
        .map(CompletableFuture::join)
        .collect(Collectors.toSet());

    verify(dataClient).getForData(keysCaptor.capture());
    assertEquals(4, keysCaptor.getValue().size());
  }


  private Supplier<Mono<Map<String, Double>>> dataClinetRequestSupplier() {
    return () -> batchClientProxy.getForData(Set.of(randomAlphabetic(16), randomAlphabetic(16)));
  }

}