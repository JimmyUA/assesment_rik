package com.sergii.prykhodko.aggregator.testData;

import org.springframework.mock.web.reactive.function.server.MockServerRequest;

public class MockRequestUtils {


  public static MockServerRequest buildAllParametersEmptyRequest() {
    return MockServerRequest.builder()
        .build();
  }

  public static MockServerRequest buildEmptyShipmentsRequest() {
    return MockServerRequest.builder()
        .queryParam("tracking", "123456789,123453459")
        .queryParam("pricing", "CN,NL,BE")
        .build();
  }

  public static MockServerRequest buildEmptyTrackingRequest() {
    return MockServerRequest.builder()
        .queryParam("shipments", "123456789,123453459")
        .queryParam("pricing", "CN,NL,BE")
        .build();
  }

  public static MockServerRequest buildEmptyPricingRequest() {
    return MockServerRequest.builder()
        .queryParam("tracking", "123456789,123453459")
        .queryParam("shipments", "123456789,123453459")
        .build();
  }

  public static MockServerRequest buildAllParametersRequest() {
    return MockServerRequest.builder()
        .queryParam("tracking", "123456789,123453459")
        .queryParam("shipments", "123456789,123453459")
        .queryParam("pricing", "CN,NL,BE")
        .build();
  }
}
