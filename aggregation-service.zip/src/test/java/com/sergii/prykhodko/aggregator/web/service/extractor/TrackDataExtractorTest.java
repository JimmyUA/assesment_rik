package com.sergii.prykhodko.aggregator.web.service.extractor;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.model.SourceType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;
import java.util.Set;

import static com.sergii.prykhodko.aggregator.web.model.SourceType.PRICING;
import static com.sergii.prykhodko.aggregator.web.model.SourceType.SHIPMENTS;
import static com.sergii.prykhodko.aggregator.web.model.SourceType.TRACK;
import static java.util.Collections.emptyMap;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class TrackDataExtractorTest {

  @Spy
  private TrackDataExtractor trackDataExtractor;

  @Test
  void correctManagementSourceType() {
    SourceType managedSourceType = trackDataExtractor.managedSourceType();

    assertEquals(managedSourceType, TRACK);
    assertNotEquals(managedSourceType, SHIPMENTS);
    assertNotEquals(managedSourceType, PRICING);
  }

  @Test
  void extractsPricingDataCorrect() {
    String orderNumber = "135751335";
    AggregationDto aggregationDto = buildAggregationDto(orderNumber);
    String orderNumberKey = orderNumber.toString();
    OutboundData outboundShipmentsData = OutboundData.trackData(Map.of(orderNumberKey, "COMPLETED"));

    Map<String, ?> trackData = trackDataExtractor.extract(aggregationDto, outboundShipmentsData);

    assertEquals(trackData.get(orderNumberKey), outboundShipmentsData.getResponseData().get(orderNumberKey));
  }

  @Test
  void nullValuesIfEmptyOutboundData() {
    String orderNumber = "135751335L";
    AggregationDto aggregationDto = buildAggregationDto(orderNumber);
    OutboundData outboundPricingData = OutboundData.shipmentsData(emptyMap());

    Map<String, ?> trackData = trackDataExtractor.extract(aggregationDto, outboundPricingData);

    assertFalse(trackData.isEmpty());
    assertNull(trackData.get(orderNumber));
  }

  private AggregationDto buildAggregationDto(String orderNumber) {
    return AggregationDto.builder()
        .track(Set.of(orderNumber))
        .build();
  }
}