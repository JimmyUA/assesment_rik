package com.sergii.prykhodko.aggregator.web.service.extractor;

import com.sergii.prykhodko.aggregator.web.model.AggregationDto;
import com.sergii.prykhodko.aggregator.web.model.OutboundData;
import com.sergii.prykhodko.aggregator.web.model.SourceType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.sergii.prykhodko.aggregator.web.model.SourceType.PRICING;
import static com.sergii.prykhodko.aggregator.web.model.SourceType.SHIPMENTS;
import static com.sergii.prykhodko.aggregator.web.model.SourceType.TRACK;
import static java.util.Collections.emptyMap;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class ShipmentsDataExtractorTest {

  @Spy
  private ShipmentsDataExtractor shipmentsDataExtractor;

  @Test
  void correctManagementSourceType() {
    SourceType managedSourceType = shipmentsDataExtractor.managedSourceType();

    assertEquals(managedSourceType, SHIPMENTS);
    assertNotEquals(managedSourceType, PRICING);
    assertNotEquals(managedSourceType, TRACK);
  }

  @Test
  void extractsPricingDataCorrect() {
    String orderNumber = "135751335L";
    OutboundData<List<String>> outboundShipmentsData = OutboundData.shipmentsData(Map.of(orderNumber, List.of("COMPLETED")));
    AggregationDto aggregationDto = buildAggregationDto(orderNumber);

    Map<String, ?> pricingData = shipmentsDataExtractor.extract(aggregationDto, outboundShipmentsData);

    assertEquals(pricingData.get(orderNumber), outboundShipmentsData.getResponseData().get(orderNumber));
  }

  @Test
  void nullValuesIfEmptyOutboundData() {
    String orderNumber = "135751335L";
    AggregationDto aggregationDto = buildAggregationDto(orderNumber);
    OutboundData<List<String>> outboundPricingData = OutboundData.shipmentsData(emptyMap());

    Map<String, ?> shipmentsData = shipmentsDataExtractor.extract(aggregationDto, outboundPricingData);

    assertFalse(shipmentsData.isEmpty());
    assertNull(shipmentsData.get(orderNumber));
  }

  private AggregationDto buildAggregationDto(String orderNumber) {
    return AggregationDto.builder()
        .shipments(Set.of(orderNumber))
        .build();
  }
}