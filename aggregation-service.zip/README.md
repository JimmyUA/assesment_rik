# AGGREGATOR SERVICE

## Description

The goal of the service is reducing web traffic by providing facade access to the other services  (Shipments, Track and Pricing)
Client can provide request keys to mentioned services and get aggregated response as well as aggregate keys from few responses into batches with certain
threshold

## Request Sample
```
GET http://<host>:8080/aggregation?pricing=NL,CN&track=119347263,124456891&shipments=109347263,123458891
```

### Response

```json
{
    "pricing": {
        "CN": 77.167763006852,
        "NL": 78.37179350625252
            },
    "track": {
        "119347263": null,
        "124456891": null
            },
    "shipments": {
        "109347263": ["box","box","pallet"],
        "123458891": ["pallet"]
            }
}
```

<mark>NOTE: in case of downstream service failure `null` values will be assigned for request keys (track object in the example above)</mark>

###SLA 

Service should respond within 10 sec for 99th percentile

##Run application

As long as application is dependent on 3 services it has 2 start-up options:

* Standalone start-up
* Start-up in a docker along with services it depends on (requires Docker to be installed)

###Windows - shell script

* start.bat - standalone start-up
* start-docker.bat - docker start-up


###Linux/MacOS

* start.sh - standalone start-up
* start-docker.sh - docker start-up

##Configuration

###Standalone start-up

To configure your standalone start-up please use /src/main/resources/application.yml configuration file

```yaml
server:
  port: ${AGGREGATOR_PORT:8080} (1)

aggregator:
  client:
    baseUri: ${BACKEND_SERVICES_URI:http://localhost:9090} (2)
    batch:
      batchKeysTimeoutSeconds: ${BATCH_KEYS_TIMEOUT:5} (3)
      keysThreshold: ${KEYS_THRESHOLD:5} (4)
```

1. port your service will be listening on
2. backend services uri
3. timeout for keys batch accumulation ( <mark>IMPORTANT!!! By increasing timeout you will violate service response time SLA</mark>)
4. amount of keys is required to accumulate before downstream service is going to be called


It is possible to configure the application by setting up correspondent environmental variables:

* AGGREGATOR_PORT
* BACKEND_SERVICES_URI
* BATCH_KEYS_TIMEOUT
* KEYS_THRESHOLD

### Docker start-up

Docker start-up is preconfigured with correct `BACKEND_SERVICES_URI`

To change `batchKeysTimeoutSeconds` or `keysThreshold` it is possible to change appropriate variables in `docker-compose.yml` file 
`BATCH_KEYS_TIMEOUT` and `KEYS_THRESHOLD` respectively

##Run instructions

In case of Linux system and docker start-up

Precondition: gradle and docker are installed on machine

1. Extract this archive to the directory of your choice
2. Navigate to the root of the directory you have extracted contend of the archive to
3. Make start script executable by running console command
```shell
chmod +x start-docker.sh
```
4. Run console command

```shell
./start-docker.sh
```
3. Enjoy