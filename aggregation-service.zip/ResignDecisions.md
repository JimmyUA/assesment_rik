# Design Decisions

##Service basic libraries:

* Spring boot 
* Reactive web

###AS-1

* I want to build an endpoint which receive the request make 3 separate calls using reactive approach as system 
behavior looks quite async fashion, combine everything into one response upon the receival of all 3 responses from external services
and respond with it.

* After implementation of the functionality decided to make more clear abstraction separation and reduce duplicated code


###AS-2

* To make implementation less robust and well divided on abstractions decided to create a Proxy client which will be responsible for grouping
request parameters.
* For implementing gathering batch with the threshold decided to use CountDown latch which is counting down amount of unique keys
until threshold is reached and then all threads which had been waiting for data getting the same mono

###AS-3

Add timeout to CountDownLatch so if after certain time there are no enough keys in a batch data client is being called.
