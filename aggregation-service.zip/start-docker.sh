#!/usr/bin/env sh
gradle build
docker-compose up
