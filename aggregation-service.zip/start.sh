#!/usr/bin/env sh
gradle run
